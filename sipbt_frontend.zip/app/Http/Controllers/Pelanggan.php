<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class Pelanggan extends Controller
{
    //
    public function index(Request $request)
    {
        if ($request->session()->get('login')) {
            $getSesionId = $request->session()->get('id');
            $users = DB::table('tb_user')->where('id_user', $getSesionId)->limit(1)->first();
            
            $data = [
                'menu'      =>  'home',
                'submenu'   =>  'pelanggan',
                'nama'      =>  $users->nama_user,
            ];
            return view('pelanggan/index_afterlogin', $data);
        } else {
            $data = [
                'menu'      => 'home',
                'submenu'   => 'pelanggan',
            ];
            return view('pelanggan/index', $data);
        }
    }

    public function tentang_kami()
    {
        $data =
            [
                'menu'      => 'tentang-kami',
                'submenu'   => 'pelanggan',
            ];
        return view('pelanggan/tentangkami', $data);
    }

    public function registrasi()
    {
        $data =
        [
            'menu'      => 'registrasi',
            'submenu'   => 'pelanggan',
        ];
        return view('pelanggan/registrasi', $data);
    }

    public function create_registrasi(Request $request)
    {
        date_default_timezone_set('Asia/Jakarta');
        DB::table('tb_user')->insert([
            'nama_user' => $request->nama,
            'nomortelepon_user' => $request->nomortelepon,
            'alamat_user' => $request->alamat,
            'username_user' => $request->username,
            'password_user' => $request->password,
            'role_user' => '3',
            'status_user'   => '1',
            'created_user'  => date('Y-m-d H:i:s'),
        ]);
        return redirect()->to('/login');
    }

    public function login(Request $request)
    {
        if (!$request->session()->get('login')) {
            $data =
                [
                    'menu'      => 'login',
                    'submenu'   => 'pelanggan',
                ];
            return view('pelanggan/login', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function process_login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $users = DB::table('tb_user')->where('username_user', $username)->where('password_user', $password)->limit(1)->get();

        if ($users) {
            foreach ($users as $key) {
                $data_id        = $key->id_user;
                $data_username  = $key->username_user;
                $data_role      = $key->role_user;
            }
            $request->session()->put('id', $data_id);
            $request->session()->put('username', $data_username);
            $request->session()->put('role', $data_role);
            $request->session()->put('login', TRUE);

            if ($data_role == 1) {
                return redirect('/dashboard');
            }
            elseif ($data_role == 2) {
                return redirect('/dashboard');
            }
            else{
                return redirect('/');
            }
        }
    }

    public function detail_one()
    {
        return view('pelanggan/detail_one');
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect('/');
    }
}
