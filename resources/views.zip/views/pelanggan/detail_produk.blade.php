@extends('pelanggan_core/core_afterlogin')
@section('css')
<!-- SPECIFIC CSS -->
<link href="css/product_page.css" rel="stylesheet">
<!-- YOUR CUSTOM CSS -->
<link href="css/custom.css" rel="stylesheet">

@endSection
@section('content')
<div class="container">
    <div class="row mt-5 mb-5">
        <div class="col-md-6">
            <div class="all">
                <img src="<?= url('/') ?>/images/{{$produk->gambar_bibit}}" width="100%">
            </div>
        </div>
        <div class="col-md-6">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?= url('/') ?>">Home</a></li>
                    <li><a href="<?= url('/') ?>">Detail</a></li>
                    <li>{{$produk->nama_bibit}}</li>
                </ul>
            </div>
            <!-- /page_header -->
            <div class="prod_info">
                <h1>{{$produk->nama_bibit}}</h1>
                <span class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i><em>4 reviews</em></span>
                <p>{{$produk->detail_bibit}}</p>
                <div class="row">
                    <div class="col-lg-5 col-md-6">
                        <div class="price_main"><span class="new_price">Rp <?= number_format($produk->harga_bibit, 0, ',', '.') ?></span></div>
                    </div>
                </div>
                <div class="mt-3">
                    <h4>Pemesanan</h4>
                </div>
                <table class="table table-borderless">
                    <tbody>
                        <form action="<?= url('/') ?>/pelanggan/detail/{{$produk->id_produk}}/beli" method="post">
                            {{csrf_field()}}
                            <tr>
                                <td>
                                    <h5>Kuantitas</h5>
                                </td>
                                <td><input type="number" min="0" max="350" class="form-control" name="qty"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Pengiriman Ke</h5>
                                </td>
                                <td>
                                    <select name="pengiriman" class="form-control">
                                        <option selected disabled>-- PILIH PENGIRIMAN --</option>
                                        <option disabled></option>
                                        <option disabled>-- AMBIL SENDIRI --</option>
                                        <option value="21">Ambil di Toko</option>
                                        <option disabled></option>
                                        <option disabled>-- PILIH DAFTAR ALAMAT --</option>
                                        @foreach($kecamatan as $key)
                                        <option value="{{$key->kecamatan_id}}">{{$key->kecamatan_name}}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>
                    </tbody>
                </table>
                <button type="submit" name="action" value="cart" class="btn btn-primary">Tambah Ke Keranjang</button>
                <button type="submit" name="action" value="direct" class="btn btn-primary">Beli Langsung</button>
                </form>
                <div class="col-2">
                </div>
            </div>
        </div>
        <!-- /prod_info -->
    </div>
</div>
</div>
@endSection